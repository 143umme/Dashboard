# app.py
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots 
from data_transform import *

st.set_page_config(
    page_title="Fencing Preseason Dashboard",
    page_icon="🤺",
    layout="wide",
    initial_sidebar_state="collapsed"
)

with open("style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Load and clean data
df_raw = load_data()
df = clean_data(df_raw)

# Load isokinetic data (separate file)
iso_df = pd.read_csv("data/Fencing_Preseason_Isokinetic data.csv", encoding='latin-1')


# Get valid athletes
valid_athletes = df['Athletes'].dropna().unique()
if len(valid_athletes) == 0:
    st.error("No athletes found")
    st.stop()

# ======================
# SECTION 1: HEADER
# ======================
st.markdown('<div class="header-container">', unsafe_allow_html=True)
st.markdown('<div class="header-title">🤺 Fencing Preseason Dashboard</div>', unsafe_allow_html=True)
st.markdown('<div class="filter-container">', unsafe_allow_html=True)
selected_athlete = st.selectbox("Athlete", sorted(valid_athletes), key="athlete_filter")
st.markdown('</div>', unsafe_allow_html=True)
st.markdown('</div>', unsafe_allow_html=True)

# Filter to selected athlete
df = df[df['Athletes'] == selected_athlete].copy()
if df.empty:
    st.warning(f"No data for {selected_athlete}")
    st.stop()

# Helper: Safe get value (return None if column missing or NaN)
def safe_get(series, index=0):
    if series.empty:
        return None
    val = series.iloc[index]
    return val if pd.notna(val) else None

# # ======================
# # SECTION 2: METRICS
# # ======================
# st.markdown("### Athlete Overview")
# row = df.iloc[0]
# col1, col2, col3, col4 = st.columns(4)
# with col1:
#     st.metric("Name", selected_athlete)
# with col2:
#     r_comp = safe_get(df['R_Composite (%)'])
#     st.metric("Right YBT (%)", f"{r_comp:.1f}" if r_comp is not None else "N/A")
# with col3:
#     l_comp = safe_get(df['L_Composite (%)'])
#     st.metric("Left YBT (%)", f"{l_comp:.1f}" if l_comp is not None else "N/A")
# with col4:
#     asym_ybt = abs(r_comp - l_comp) if (r_comp is not None and l_comp is not None) else None
#     st.metric("YBT Asym (%)", f"{asym_ybt:.1f}" if asym_ybt is not None else "N/A")



# ======================
# SECTION 3: BALANCE & MOBILITY (4 charts)
# ======================
# st.markdown("### CMJ Jump Height Over Time")
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown("#### JUMP HEIGHT (CM)")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    jump_data = get_jump_height_data(df, 0)  # First athlete only (row 0)
    
    if jump_data and jump_data['values'][0] is not None:
        fig_jump = go.Figure()

        # Plot actual data (2025)
        fig_jump.add_trace(go.Scatter(
            x=[2025],
            y=[jump_data['values'][0]],
            mode='markers+text',
            marker=dict(size=12, color='#003366'),
            text=[f"{jump_data['values'][0]:.1f}"],
            textposition='bottom center',
            textfont=dict(color='#003366', size=12, family="Arial Black"),
            name='Jump Height',
            showlegend=False
        ))

        # Add line connecting (even if only one point — for consistency)
        fig_jump.add_trace(go.Scatter(
            x=jump_data['years'],
            y=jump_data['values'],
            mode='lines',
            line=dict(color='#003366', width=3.5),
            showlegend=False,
            opacity=0.8
        ))

        # "No Data" annotations for 2026 & 2027
        for year in [2026, 2027]:
            fig_jump.add_annotation(
                x=year,
                y=30,  # Fixed vertical position
                text="No Data",
                showarrow=False,
                font=dict(size=10, color='gray', style='italic'),
                opacity=0.7
            )

        # Update layout
        fig_jump.update_layout(
            title='',
            xaxis=dict(
                title='',
                tickmode='array',
                tickvals=[2025, 2026, 2027],
                ticktext=['2025', '2026', '2027'],
                range=[2024.5, 2027.5],
                showgrid=True,
                gridcolor='lightgray',
                gridwidth=0.8,
                zeroline=False
            ),
            yaxis=dict(
                title='Jump Height (cm)',
                range=[0, 60],
                showgrid=True,
                gridcolor='lightgray',
                gridwidth=0.8,
                zeroline=False
            ),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            height=400,
            width=400,
            margin=dict(t=30, b=40, l=50, r=30)
        )

        # Add title bar (as close as possible in Plotly)
        # fig_jump.add_annotation(
        #     x=0.5, y=1.08,
        #     xref='paper', yref='paper',
        #     text='JUMP HEIGHT (CM)',
        #     showarrow=False,
        #     font=dict(size=16, color='white', family="Arial Black"),
        #     bgcolor='#008080',
        #     borderpad=4,
        #     opacity=1
        # )

        # Athlete name as subtitle
        fig_jump.add_annotation(
            x=0.5, y=1.02,
            xref='paper', yref='paper',
            text=jump_data['name'],
            showarrow=False,
            font=dict(size=12, color='gray'),
            xanchor='center'
        )

        st.plotly_chart(fig_jump, use_container_width=True, key="jump_height_timeline")
    
    else:
        st.caption("Jump height data not available for this athlete.")

    st.markdown('</div>', unsafe_allow_html=True)

# Use col2 for notes or legend
with col2:
    st.markdown("#### Mean PEAK POWER / BM (W/KG)")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    power_data = get_cmj_peak_power_data(df, athlete_row=0)

    if power_data and pd.notna(power_data['value_2025']):
        fig_power = go.Figure()

        years = [2025, 2026, 2027]
        values = [power_data['value_2025'], None, None]
        colors = ['#4da6ff', '#cccccc', '#cccccc']

        # Bar chart
        fig_power.add_trace(go.Bar(
            x=years,
            y=values,
            marker=dict(
                color=colors,
                line=dict(color='black', width=1.2)
            ),
            width=0.6,
            showlegend=False
        ))

        # Annotate 2025 value
        fig_power.add_annotation(
            x=2025,
            y=power_data['value_2025'] + 1,
            text=f"{power_data['value_2025']:.1f}",
            showarrow=False,
            font=dict(size=12, color='#4da6ff', family="Arial Black"),
            xanchor='center'
        )

        # "No Data" labels
        for yr in [2026, 2027]:
            fig_power.add_annotation(
                x=yr,
                y=20,
                text="No Data",
                showarrow=False,
                font=dict(size=11, color='gray', style='italic'),
                opacity=0.8,
                xanchor='center'
            )

        # Y-axis limit
        y_max = max(50, power_data['value_2025'] * 1.3)

        # Layout
        fig_power.update_layout(
            title='',
            xaxis=dict(
                tickmode='array',
                tickvals=years,
                ticktext=[str(y) for y in years],
                range=[2024.2, 2027.8],
                showgrid=True,
                gridcolor='lightgray',
                zeroline=False
            ),
            yaxis=dict(
                title='Power (W/kg)',
                range=[0, y_max],
                showgrid=True,
                gridcolor='lightgray',
                zeroline=False
            ),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            height=400,
            width=400,
            margin=dict(t=70, b=40, l=50, r=30)
        )

        # # Teal title bar
        # fig_power.add_annotation(
        #     x=0.5, y=1.14,
        #     xref='paper', yref='paper',
        #     # text='Mean PEAK POWER / BM (W/KG)',
        #     showarrow=False,
        #     font=dict(size=14, color='white', family="Arial Black"),
        #     bgcolor='#008080',
        #     borderpad=6,
        #     xanchor='center'
        # )

        # Athlete name
        fig_power.add_annotation(
            x=0.5, y=1.07,
            xref='paper', yref='paper',
            text=power_data['name'],
            showarrow=False,
            font=dict(size=12, color='gray'),
            xanchor='center'
        )

        # Legend hint
        fig_power.add_annotation(
            x=0.5, y=1.01,
            xref='paper', yref='paper',
            text="2025 (September)",
            showarrow=False,
            font=dict(size=11),
            bgcolor="#f0f0f0",
            bordercolor="#4da6ff",
            borderwidth=1.5,
            xanchor='center'
        )

        st.plotly_chart(fig_power, use_container_width=True, key="cmj_peak_power_bm_chart")
    else:
        st.caption("CMJ peak power data not available.")

    st.markdown('</div>', unsafe_allow_html=True)

# Chart 3: YBT Directions (Right)
with col3:  # or col4 — whichever you prefer
    st.markdown("#### KTW: Dominant vs Non-Dominant (cm)")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    ktw_data = get_ktw_longitudinal_data(df, athlete_row=0)

    if ktw_data and (pd.notna(ktw_data['dominant_2025']) or pd.notna(ktw_data['non_dominant_2025'])):
        fig_ktw = go.Figure()

        years = [2025, 2026, 2027]
        x_pos = np.arange(len(years))

        # Only 2025 has data
        dom_vals = [ktw_data['dominant_2025'], None, None]
        non_dom_vals = [ktw_data['non_dominant_2025'], None, None]

        # Non-Dominant (skyblue)
        fig_ktw.add_trace(go.Bar(
            x=[2025 - 0.2],  # offset for 2025 only
            y=[ktw_data['non_dominant_2025']],
            name='Non-Dominant',
            marker_color='skyblue',
            width=0.4,
            showlegend=True
        ))

        # Dominant (navy)
        fig_ktw.add_trace(go.Bar(
            x=[2025 + 0.2],
            y=[ktw_data['dominant_2025']],
            name='Dominant',
            marker_color='navy',
            width=0.4,
            showlegend=True
        ))

        # "No Data" labels for 2026 & 2027 (both sides)
        for yr in [2026, 2027]:
            fig_ktw.add_annotation(
                x=yr - 0.2, y=8,
                text="No Data", showarrow=False,
                font=dict(size=10, color='gray', style='italic'), opacity=0.7
            )
            fig_ktw.add_annotation(
                x=yr + 0.2, y=8,
                text="No Data", showarrow=False,
                font=dict(size=10, color='gray', style='italic'), opacity=0.7
            )

        # Normative line at 10 cm
        fig_ktw.add_hline(
            y=10,
            line=dict(color='green', dash='dot', width=2),
            annotation_text="Norm: 10 cm",
            annotation_position="top right",
            annotation_font_size=11
        )

        # Layout
        fig_ktw.update_layout(
            title='',
            xaxis=dict(
                tickmode='array',
                tickvals=years,
                ticktext=[str(y) for y in years],
                range=[2024.5, 2027.5],
                showgrid=True,
                gridcolor='lightgray',
                zeroline=False
            ),
            yaxis=dict(
                title='KTW Distance (cm)',
                range=[0, 16],
                showgrid=True,
                gridcolor='lightgray',
                zeroline=False
            ),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            height=400,
            width=400,
            margin=dict(t=70, b=40, l=50, r=30),
            barmode='group'
        )

        # Title bar
        fig_ktw.add_annotation(
            x=0.5, y=1.14,
            xref='paper', yref='paper',
            text='KTW DOMINANT vs NON-DOMINANT',
            showarrow=False,
            font=dict(size=14, color='white', family="Arial Black"),
            bgcolor='#008080',
            borderpad=6,
            xanchor='center'
        )

        # Athlete name
        fig_ktw.add_annotation(
            x=0.5, y=1.07,
            xref='paper', yref='paper',
            text=ktw_data['name'],
            showarrow=False,
            font=dict(size=12, color='gray'),
            xanchor='center'
        )

        st.plotly_chart(fig_ktw, use_container_width=True, key="ktw_dominant_comparison")
    else:
        st.caption("KTW data not available.")

    st.markdown('</div>', unsafe_allow_html=True)

# Chart 4: YBT Directions (Left)
with col4:
    st.markdown("#### ")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)
    # Placeholder figure for missing data
    fig = go.Figure()
    fig.update_layout(
        title="YBT Left Directions (%)",
        title_x=0.5,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        height=400,
        # width=400,
        margin=dict(t=40, b=40, l=50, r=30)
    )
    fig.add_annotation(
        text="Left YBT detail missing",
        x=0.5, y=0.5,
        xref="paper", yref="paper",
        showarrow=False,
        font=dict(size=12, color="gray"),
        align="center"
    )

    st.plotly_chart(fig, use_container_width=False, key="ybt_left_bar")
    st.markdown('</div>', unsafe_allow_html=True)



# ======================
# SECTION 4
# ======================
# st.markdown("### CMJ Performance vs Team Average")

col1, col2, col3 = st.columns(3)

# with col1:
#     st.markdown("#### SLJ Mean vs Limb Asymmetry")
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)

#     slj_data = get_slj_mean_asymmetry_data(df, selected_athlete)

#     if slj_data and len(slj_data['metrics']) > 0:
#         fig = go.Figure()

#         y_labels = slj_data['metrics']
#         y_positions = list(range(len(y_labels)))
#         non_dom = slj_data['non_dominant']
#         dom = slj_data['dominant']
#         asym = slj_data['asymmetry']

#         # === LEFT: Lollipop lines ===
#         for i, (L, R) in enumerate(zip(non_dom, dom)):
#             fig.add_shape(
#                 type='line',
#                 x0=L, x1=R,
#                 y0=i, y1=i,
#                 line=dict(color='gray', width=2.5),
#                 layer='below'
#             )

#         # Non-Dominant (green)
#         fig.add_trace(go.Scatter(
#             x=non_dom,
#             y=y_positions,
#             mode='markers+text',
#             marker=dict(color='green', size=12, line=dict(color='black', width=1.2)),
#             text=[f"{L:.1f}" for L in non_dom],
#             textposition='top center',
#             textfont=dict(size=9),
#             name='Non-Dominant',
#             showlegend=True
#         ))

#         # Dominant (orange)
#         fig.add_trace(go.Scatter(
#             x=dom,
#             y=y_positions,
#             mode='markers+text',
#             marker=dict(color='orange', size=12, line=dict(color='black', width=1.2)),
#             text=[f"{R:.1f}" for R in dom],
#             textposition='top center',
#             textfont=dict(size=9),
#             name='Dominant',
#             showlegend=True
#         ))

#         # Asymmetry % between points
#         for i, A in enumerate(asym):
#             mid_x = (non_dom[i] + dom[i]) / 2
#             fig.add_annotation(
#                 x=mid_x,
#                 y=i + 0.25,
#                 text=f"{A:.1f}%",
#                 showarrow=False,
#                 font=dict(size=10, color='green', family="Arial Black"),
#                 xanchor='center'
#             )

#         # === RIGHT: Asymmetry bars (offset) ===
#         asym_x_offset = 150
#         for i, A in enumerate(asym):
#             fig.add_shape(
#                 type='rect',
#                 x0=asym_x_offset,
#                 x1=asym_x_offset + A,
#                 y0=i - 0.3,
#                 y1=i + 0.3,
#                 fillcolor='orange',
#                 line=dict(color='darkred', width=1.2)
#             )
#             fig.add_annotation(
#                 x=asym_x_offset + A + 2,
#                 y=i,
#                 text=f"{A:.1f}%",
#                 showarrow=False,
#                 font=dict(size=10),
#                 xanchor='left'
#             )

#         # Layout
#         fig.update_layout(
#             title='',
#             xaxis=dict(
#                 title="Value",
#                 range=[-10, 160],
#                 tickmode='linear',
#                 dtick=20,
#                 showgrid=True,
#                 gridcolor='lightgray',
#                 zeroline=False
#             ),
#             yaxis=dict(
#                 title="",
#                 tickmode='array',
#                 tickvals=y_positions,
#                 ticktext=y_labels,
#                 range=[-0.5, len(y_labels) - 0.5]
#             ),
#             plot_bgcolor='rgba(0,0,0,0)',
#             paper_bgcolor='rgba(0,0,0,0)',
#             height=450,
#             margin=dict(t=70, b=50, l=120, r=80),
#             legend=dict(
#                 x=0.01, y=0.98,
#                 xanchor='left', yanchor='top',
#                 bgcolor='rgba(255,255,255,0.8)'
#             )
#         )

#         # Asymmetry axis label
#         max_asym = max(asym) if asym else 5
#         fig.add_annotation(
#             x=asym_x_offset + max_asym / 2,
#             y=len(y_labels) - 0.2,
#             text="Asymmetry %",
#             showarrow=False,
#             font=dict(size=12),
#             xanchor='center'
#         )

#         # Teal title bar
#         fig.add_annotation(
#             x=0.5, y=1.08,
#             xref='paper', yref='paper',
#             text='SLJ MEAN – LIMB ASYMMETRY',
#             showarrow=False,
#             font=dict(size=14, color='white', family="Arial Black"),
#             bgcolor='#008080',
#             borderpad=6,
#             xanchor='center'
#         )

#         # Athlete name
#         fig.add_annotation(
#             x=0.5, y=1.02,
#             xref='paper', yref='paper',
#             text=slj_data['name'],
#             showarrow=False,
#             font=dict(size=12, color='gray'),
#             xanchor='center'
#         )

#         st.plotly_chart(fig, use_container_width=True, key="slj_mean_asymmetry_chart")
#     else:
#         st.caption("SLJ mean asymmetry data not available for this athlete.")

#     st.markdown('</div>', unsafe_allow_html=True)

with col1:
    st.markdown("#### SLJ Mean vs Limb Asymmetry")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    slj_data = get_slj_mean_asymmetry_data(df, selected_athlete)

    if slj_data and len(slj_data['metrics']) > 0:
        fig = go.Figure()

        y_labels = slj_data['metrics']
        y_positions = list(range(len(y_labels)))
        non_dom = slj_data['non_dominant']
        dom = slj_data['dominant']
        asym = slj_data['asymmetry']

        # === LEFT: Lollipop lines ===
        for i, (L, R) in enumerate(zip(non_dom, dom)):
            fig.add_shape(
                type='line',
                x0=L, x1=R,
                y0=i, y1=i,
                line=dict(color='gray', width=2.5),
                layer='below'
            )

        # Non-Dominant (green)
        fig.add_trace(go.Scatter(
            x=non_dom,
            y=y_positions,
            mode='markers+text',
            marker=dict(color='green', size=12, line=dict(color='black', width=1.2)),
            text=[f"{L:.1f}" for L in non_dom],
            textposition='top center',
            textfont=dict(size=9),
            name='Non-Dominant',
            showlegend=True
        ))

        # Dominant (orange)
        fig.add_trace(go.Scatter(
            x=dom,
            y=y_positions,
            mode='markers+text',
            marker=dict(color='orange', size=12, line=dict(color='black', width=1.2)),
            text=[f"{R:.1f}" for R in dom],
            textposition='top center',
            textfont=dict(size=9),
            name='Dominant',
            showlegend=True
        ))

        # Asymmetry % between points
        for i, A in enumerate(asym):
            mid_x = (non_dom[i] + dom[i]) / 2
            fig.add_annotation(
                x=mid_x,
                y=i + 0.25,
                text=f"{A:.1f}%",
                showarrow=False,
                font=dict(size=10, color='green', family="Arial Black"),
                xanchor='center'
            )

        # === RIGHT: Asymmetry bars (offset) ===
        asym_x_offset = 150
        for i, A in enumerate(asym):
            fig.add_shape(
                type='rect',
                x0=asym_x_offset,
                x1=asym_x_offset + A,
                y0=i - 0.3,
                y1=i + 0.3,
                fillcolor='orange',
                line=dict(color='darkred', width=1.2)
            )
            fig.add_annotation(
                x=asym_x_offset + A + 2,
                y=i,
                text=f"{A:.1f}%",
                showarrow=False,
                font=dict(size=10),
                xanchor='left'
            )

        # Layout
        fig.update_layout(
            title='',
            xaxis=dict(
                title="Value",
                range=[-10, 160],
                tickmode='linear',
                dtick=20,
                showgrid=True,
                gridcolor='lightgray',
                zeroline=False
            ),
            yaxis=dict(
                title="",
                tickmode='array',
                tickvals=y_positions,
                ticktext=y_labels,
                range=[-0.5, len(y_labels) - 0.5]
            ),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            height=450,
            margin=dict(t=70, b=50, l=120, r=80),
            legend=dict(
                x=0.01, y=0.98,
                xanchor='left', yanchor='top',
                bgcolor='rgba(255,255,255,0.8)'
            )
        )

        # Asymmetry axis label
        max_asym = max(asym) if asym else 5
        fig.add_annotation(
            x=asym_x_offset + max_asym / 2,
            y=len(y_labels) - 0.2,
            text="Asymmetry %",
            showarrow=False,
            font=dict(size=12),
            xanchor='center'
        )

        # Teal title bar
        fig.add_annotation(
            x=0.5, y=1.08,
            xref='paper', yref='paper',
            text='SLJ MEAN – LIMB ASYMMETRY',
            showarrow=False,
            font=dict(size=14, color='white', family="Arial Black"),
            bgcolor='#008080',
            borderpad=6,
            xanchor='center'
        )

        # Athlete name
        fig.add_annotation(
            x=0.5, y=1.02,
            xref='paper', yref='paper',
            text=slj_data['name'],
            showarrow=False,
            font=dict(size=12, color='gray'),
            xanchor='center'
        )

        st.plotly_chart(fig, use_container_width=True, key="slj_mean_asymmetry_chart")
    else:
        # === PLACEHOLDER FOR MISSING DATA ===
        fig = go.Figure()
        fig.update_layout(
            title="SLJ Mean – Limb Asymmetry",
            title_x=0.5,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            height=450,
            margin=dict(t=70, b=50, l=120, r=80)
        )
        fig.add_annotation(
            text="SLJ mean asymmetry data not available for this athlete",
            x=0.5, y=0.5,
            xref="paper", yref="paper",
            showarrow=False,
            font=dict(size=12, color="gray"),
            align="center"
        )
        st.plotly_chart(fig, use_container_width=True, key="slj_mean_placeholder")

    st.markdown('</div>', unsafe_allow_html=True)


# with col2:
#     st.markdown("#### Y-Balance Test (YBT) Directional")
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)

#     ybt_data = get_ybt_directional_data(df, selected_athlete)

#     if ybt_data:
#         metrics = ybt_data['metrics']
#         left_vals = ybt_data['left']
#         right_vals = ybt_data['right']
#         athlete_name = ybt_data['name']

#         # Check if any data exists
#         has_data = any(pd.notna(v) for v in left_vals + right_vals)

#         if has_data:
#             fig_ybt = go.Figure()

#             # Left Leg
#             fig_ybt.add_trace(go.Scatter(
#                 y=metrics,
#                 x=left_vals,
#                 mode='lines+markers',
#                 name='Left Leg',
#                 line=dict(color='blue'),
#                 marker=dict(size=10)
#             ))
#             # Right Leg
#             fig_ybt.add_trace(go.Scatter(
#                 y=metrics,
#                 x=right_vals,
#                 mode='lines+markers',
#                 name='Right Leg',
#                 line=dict(color='orange'),
#                 marker=dict(size=10)
#             ))

#             # Normative line at 94%
#             fig_ybt.add_vline(
#                 x=94,
#                 line_dash="dash",
#                 line_color="red",
#                 annotation_text="Norm: 94%",
#                 annotation_position="top left"
#             )

#             # Top-right annotation
#             fig_ybt.add_annotation(
#                 xref="paper", yref="paper",
#                 x=1.0, y=1.0,
#                 text="Diff Norm: <4%",
#                 showarrow=False,
#                 font=dict(size=12),
#                 bgcolor="white",
#                 opacity=0.8,
#                 xanchor="right", yanchor="top"
#             )

#             # Disbalance annotations
#             for i, metric in enumerate(metrics):
#                 L, R = left_vals[i], right_vals[i]
#                 if pd.notna(L) and pd.notna(R):
#                     disbalance = abs(L - R)
#                     fig_ybt.add_annotation(
#                         y=metric,
#                         x=(L + R) / 2,
#                         text=f"{disbalance:.1f}%",
#                         showarrow=False,
#                         font=dict(size=10),
#                         bgcolor="white",
#                         opacity=0.8
#                     )

#             # Layout
#             fig_ybt.update_layout(
#                 title='',
#                 yaxis_title='Direction',
#                 xaxis_title='Reach (%)',
#                 height=500,
#                 plot_bgcolor='rgba(0,0,0,0)',
#                 paper_bgcolor='rgba(0,0,0,0)',
#                 legend=dict(x=1.0, y=0.9, xanchor="right", yanchor="top"),
#                 margin=dict(t=30)
#             )

#             # Set x-axis range
#             all_vals = [v for v in left_vals + right_vals if pd.notna(v)]
#             if all_vals:
#                 x_min = min(all_vals) - 5
#                 x_max = max(all_vals) + 5
#                 fig_ybt.update_xaxes(range=[x_min, x_max])

#             st.plotly_chart(fig_ybt, use_container_width=True, key="ybt_directional_chart")
#         else:
#             st.caption("YBT data missing for both legs.")
#     else:
#         st.caption("YBT data not available for this athlete.")

#     st.markdown('</div>', unsafe_allow_html=True)
with col2:
    st.markdown("#### Y-Balance Test (YBT) Directional")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    ybt_data = get_ybt_directional_data(df, selected_athlete)

    if ybt_data:
        metrics = ybt_data['metrics']
        left_vals = ybt_data['left']
        right_vals = ybt_data['right']
        athlete_name = ybt_data['name']

        has_data = any(pd.notna(v) for v in left_vals + right_vals)

        if has_data:
            fig_ybt = go.Figure()

            # Left Leg
            fig_ybt.add_trace(go.Scatter(
                y=metrics,
                x=left_vals,
                mode='lines+markers',
                name='Left Leg',
                line=dict(color='blue'),
                marker=dict(size=10)
            ))
            # Right Leg
            fig_ybt.add_trace(go.Scatter(
                y=metrics,
                x=right_vals,
                mode='lines+markers',
                name='Right Leg',
                line=dict(color='orange'),
                marker=dict(size=10)
            ))

            # Normative line at 94%
            fig_ybt.add_vline(
                x=94,
                line_dash="dash",
                line_color="red",
                annotation_text="Norm: 94%",
                annotation_position="top left"
            )

            # Top-right annotation
            fig_ybt.add_annotation(
                xref="paper", yref="paper",
                x=1.0, y=1.0,
                text="Diff Norm: <4%",
                showarrow=False,
                font=dict(size=12),
                bgcolor="white",
                opacity=0.8,
                xanchor="right", yanchor="top"
            )

            # Disbalance annotations
            for i, metric in enumerate(metrics):
                L, R = left_vals[i], right_vals[i]
                if pd.notna(L) and pd.notna(R):
                    disbalance = abs(L - R)
                    fig_ybt.add_annotation(
                        y=metric,
                        x=(L + R) / 2,
                        text=f"{disbalance:.1f}%",
                        showarrow=False,
                        font=dict(size=10),
                        bgcolor="white",
                        opacity=0.8
                    )

            # Layout
            fig_ybt.update_layout(
                title='',
                yaxis_title='Direction',
                xaxis_title='Reach (%)',
                height=450,  # ✅ min height
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                legend=dict(x=1.0, y=0.9, xanchor="right", yanchor="top"),
                margin=dict(t=30, b=40, l=60, r=40)
            )

            # Set x-axis range
            all_vals = [v for v in left_vals + right_vals if pd.notna(v)]
            if all_vals:
                x_min = max(0, min(all_vals) - 5)
                x_max = max(all_vals) + 5
                fig_ybt.update_xaxes(range=[x_min, x_max])

            st.plotly_chart(fig_ybt, use_container_width=True, key="ybt_directional_chart")
        else:
            # Placeholder when data exists but all values are missing
            fig = go.Figure()
            fig.update_layout(
                title="Y-Balance Test (YBT) Directional",
                title_x=0.5,
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                xaxis=dict(visible=False),
                yaxis=dict(visible=False),
                height=450,
                margin=dict(t=40, b=40, l=50, r=30)
            )
            fig.add_annotation(
                text="YBT data missing for both legs",
                x=0.5, y=0.5,
                xref="paper", yref="paper",
                showarrow=False,
                font=dict(size=12, color="gray"),
                align="center"
            )
            st.plotly_chart(fig, use_container_width=True, key="ybt_placeholder_missing_data")
    else:
        # Placeholder when athlete has no YBT columns or data
        fig = go.Figure()
        fig.update_layout(
            title="Y-Balance Test (YBT) Directional",
            title_x=0.5,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            height=450,
            margin=dict(t=40, b=40, l=50, r=30)
        )
        fig.add_annotation(
            text="YBT data not available for this athlete",
            x=0.5, y=0.5,
            xref="paper", yref="paper",
            showarrow=False,
            font=dict(size=12, color="gray"),
            align="center"
        )
        st.plotly_chart(fig, use_container_width=True, key="ybt_placeholder_no_data")

    st.markdown('</div>', unsafe_allow_html=True)


# with col3:
#     st.markdown("#### SLH Mean RSI (m/s)")
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)

#     slh_data = get_slh_rsi_data(df, selected_athlete)

#     if slh_data and (pd.notna(slh_data['non_dominant']) or pd.notna(slh_data['dominant'])):
#         fig_slh = go.Figure()

#         y_pos = 0
#         L = slh_data['non_dominant']
#         R = slh_data['dominant']
#         asym = slh_data['asymmetry']
#         name = slh_data['name']

#         # Horizontal line between points
#         if pd.notna(L) and pd.notna(R):
#             fig_slh.add_shape(
#                 type='line',
#                 x0=L, x1=R,
#                 y0=y_pos, y1=y_pos,
#                 line=dict(color='gray', width=3),
#                 layer='below'
#             )

#         # Non-Dominant (blue)
#         if pd.notna(L):
#             fig_slh.add_trace(go.Scatter(
#                 x=[L], y=[y_pos],
#                 mode='markers',
#                 marker=dict(color='#1f77b4', size=20, line=dict(color='black', width=1.5)),
#                 name='Non-Dominant',
#                 showlegend=True
#             ))

#         # Dominant (red)
#         if pd.notna(R):
#             fig_slh.add_trace(go.Scatter(
#                 x=[R], y=[y_pos],
#                 mode='markers',
#                 marker=dict(color='#d62728', size=20, line=dict(color='black', width=1.5)),
#                 name='Dominant',
#                 showlegend=True
#             ))

#         # Asymmetry % between dots (if both exist)
#         if pd.notna(L) and pd.notna(R) and asym is not None:
#             mid_x = (L + R) / 2
#             fig_slh.add_annotation(
#                 x=mid_x,
#                 y=y_pos,
#                 text=f"{asym:.1f}%",
#                 showarrow=False,
#                 font=dict(size=11, color='white', family="Arial Black"),
#                 xanchor='center',
#                 yanchor='middle',
#                 bgcolor='darkred',
#                 borderpad=4
#             )

#         # Layout
#         fig_slh.update_layout(
#             title='',
#             xaxis=dict(
#                 title="RSI (m/s)",
#                 range=[0.1, 0.6],
#                 tickmode='array',
#                 tickvals=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
#                 ticktext=['0.1', '0.2', '0.3', '0.4', '0.5', '0.6'],
#                 showgrid=True,
#                 gridcolor='lightgray',
#                 zeroline=False
#             ),
#             yaxis=dict(
#                 tickmode='array',
#                 tickvals=[y_pos],
#                 ticktext=[name],
#                 showticklabels=True,
#                 showgrid=False,
#                 zeroline=False
#             ),
#             plot_bgcolor='rgba(0,0,0,0)',
#             paper_bgcolor='rgba(0,0,0,0)',
#             height=200,
#             margin=dict(t=40, b=40, l=80, r=40),
#             legend=dict(
#                 x=1.0, y=1.0,
#                 xanchor='right', yanchor='top',
#                 bgcolor='rgba(255,255,255,0.8)'
#             )
#         )

#         # Teal title bar (optional but consistent)
#         fig_slh.add_annotation(
#             x=0.5, y=1.25,
#             xref='paper', yref='paper',
#             text='SLH MEAN RSI',
#             showarrow=False,
#             font=dict(size=12, color='white', family="Arial Black"),
#             bgcolor='#008080',
#             borderpad=4,
#             xanchor='center'
#         )

#         st.plotly_chart(fig_slh, use_container_width=True, key="slh_rsi_chart")
#     else:
#         st.caption("SLH RSI data not available.")

#     st.markdown('</div>', unsafe_allow_html=True)

with col3:
    st.markdown("#### SLH Mean RSI (m/s)")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    slh_data = get_slh_rsi_data(df, selected_athlete)

    if slh_data and (pd.notna(slh_data['non_dominant']) or pd.notna(slh_data['dominant'])):
        fig_slh = go.Figure()

        y_pos = 0
        L = slh_data['non_dominant']
        R = slh_data['dominant']
        asym = slh_data['asymmetry']
        name = slh_data['name']

        # Horizontal line between points
        if pd.notna(L) and pd.notna(R):
            fig_slh.add_shape(
                type='line',
                x0=L, x1=R,
                y0=y_pos, y1=y_pos,
                line=dict(color='gray', width=3),
                layer='below'
            )

        # Non-Dominant (blue)
        if pd.notna(L):
            fig_slh.add_trace(go.Scatter(
                x=[L], y=[y_pos],
                mode='markers',
                marker=dict(color='#1f77b4', size=20, line=dict(color='black', width=1.5)),
                name='Non-Dominant',
                showlegend=True
            ))

        # Dominant (red)
        if pd.notna(R):
            fig_slh.add_trace(go.Scatter(
                x=[R], y=[y_pos],
                mode='markers',
                marker=dict(color='#d62728', size=20, line=dict(color='black', width=1.5)),
                name='Dominant',
                showlegend=True
            ))

        # Asymmetry % between dots (if both exist)
        if pd.notna(L) and pd.notna(R) and asym is not None:
            mid_x = (L + R) / 2
            fig_slh.add_annotation(
                x=mid_x,
                y=y_pos,
                text=f"{asym:.1f}%",
                showarrow=False,
                font=dict(size=11, color='white', family="Arial Black"),
                xanchor='center',
                yanchor='middle',
                bgcolor='darkred',
                borderpad=4
            )

        # Layout
        fig_slh.update_layout(
            title='',
            xaxis=dict(
                title="RSI (m/s)",
                range=[0.1, 0.6],
                tickmode='array',
                tickvals=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6],
                ticktext=['0.1', '0.2', '0.3', '0.4', '0.5', '0.6'],
                showgrid=True,
                gridcolor='lightgray',
                zeroline=False
            ),
            yaxis=dict(
                tickmode='array',
                tickvals=[y_pos],
                ticktext=[name],
                showticklabels=True,
                showgrid=False,
                zeroline=False
            ),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            height=450,
            margin=dict(t=40, b=40, l=80, r=40),
            legend=dict(
                x=1.0, y=1.0,
                xanchor='right', yanchor='top',
                bgcolor='rgba(255,255,255,0.8)'
            )
        )

        # Teal title bar
        fig_slh.add_annotation(
            x=0.5, y=1.25,
            xref='paper', yref='paper',
            text='SLH MEAN RSI',
            showarrow=False,
            font=dict(size=12, color='white', family="Arial Black"),
            bgcolor='#008080',
            borderpad=4,
            xanchor='center'
        )

        st.plotly_chart(fig_slh, use_container_width=True, key="slh_rsi_chart")
    else:
        # === PLACEHOLDER FOR MISSING DATA ===
        fig = go.Figure()
        fig.update_layout(
            title="SLH Mean RSI (m/s)",
            title_x=0.5,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            height=450,
            margin=dict(t=40, b=40, l=80, r=40)
        )
        fig.add_annotation(
            text="SLH RSI data not available",
            x=0.5, y=0.5,
            xref="paper", yref="paper",
            showarrow=False,
            font=dict(size=12, color="gray"),
            align="center"
        )
        st.plotly_chart(fig, use_container_width=True, key="slh_rsi_placeholder")

    st.markdown('</div>', unsafe_allow_html=True)

# ======================
# SECTION 5: CMJ Summary vs Team Average
# ======================
# st.markdown("### CMJ Summary vs Team Average")

col1, col2, col3 = st.columns(3)

# with col1:
#     st.markdown("#### CMJ Mean – Athlete vs Team")
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)

#     cmj_data = get_cmj_team_comparison_data(df, selected_athlete)

#     if cmj_data and cmj_data['main_labels']:
#         fig = make_subplots(
#             rows=2, cols=1,
#             vertical_spacing=0.12,
#             row_heights=[0.7, 0.3]
#         )

#         # Main metrics (row 1)
#         fig.add_trace(go.Scatter(
#             x=cmj_data['athlete_main'],
#             y=cmj_data['main_labels'],
#             mode='markers',
#             name=cmj_data['name'],
#             marker=dict(color='#2ca02c', size=20, line=dict(width=2, color='black')),
#             legendgroup='athlete'
#         ), row=1, col=1)

#         fig.add_trace(go.Scatter(
#             x=cmj_data['team_main'],
#             y=cmj_data['main_labels'],
#             mode='markers',
#             name='Team Average',
#             marker=dict(color='#ff7f0e', size=20, line=dict(width=2, color='black')),
#             legendgroup='team'
#         ), row=1, col=1)

#         # RSI (row 2)
#         if cmj_data['rsi_athlete'] is not None:
#             fig.add_trace(go.Scatter(
#                 x=[cmj_data['rsi_athlete']],
#                 y=['RSI-modified (Imp-Mom)'],
#                 mode='markers',
#                 name=cmj_data['name'],
#                 showlegend=False,
#                 marker=dict(color='#2ca02c', size=25, line=dict(width=2, color='black')),
#                 legendgroup='athlete'
#             ), row=2, col=1)
#             fig.add_trace(go.Scatter(
#                 x=[cmj_data['rsi_team']],
#                 y=['RSI-modified (Imp-Mom)'],
#                 mode='markers',
#                 name='Team Average',
#                 showlegend=False,
#                 marker=dict(color='#ff7f0e', size=25, line=dict(width=2, color='black')),
#                 legendgroup='team'
#             ), row=2, col=1)

#         # Layout
#         fig.update_layout(
#             height=700,
#             plot_bgcolor='rgba(0,0,0,0)',
#             paper_bgcolor='rgba(0,0,0,0)',
#             legend=dict(x=0.01, y=0.99, bgcolor='rgba(255,255,255,0.9)'),
#             margin=dict(l=180, r=50, t=80, b=50)
#         )
#         fig.update_xaxes(range=[0, max(cmj_data['athlete_main'] + cmj_data['team_main']) * 1.15], row=1, col=1)
#         if cmj_data['rsi_athlete'] is not None:
#             fig.update_xaxes(range=[0, 1], row=2, col=1)
#         fig.update_yaxes(title="Metric", row=1, col=1)

#         # Teal title
#         fig.add_annotation(x=0.5, y=1.02, xref='paper', yref='paper',
#                            text='CMJ MEAN – ATHLETE vs TEAM',
#                            font=dict(size=14, color='white'),
#                            bgcolor='#008080', borderpad=6, xanchor='center')
#         fig.add_annotation(x=0.5, y=0.98, xref='paper', yref='paper',
#                            text=cmj_data['name'], font=dict(size=12, color='gray'), xanchor='center')

#         st.plotly_chart(fig, use_container_width=True, key="cmj_comparison")
#     else:
#         st.caption("CMJ comparison data not available.")
#     st.markdown('</div>', unsafe_allow_html=True)
with col1:
    st.markdown("#### CMJ Mean – Athlete vs Team")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    cmj_data = get_cmj_team_comparison_data(df, selected_athlete)

    if cmj_data and cmj_data['main_labels']:
        fig = make_subplots(
            rows=2, cols=1,
            vertical_spacing=0.12,
            row_heights=[0.7, 0.3]
        )

        # Main metrics (row 1)
        fig.add_trace(go.Scatter(
            x=cmj_data['athlete_main'],
            y=cmj_data['main_labels'],
            mode='markers',
            name=cmj_data['name'],
            marker=dict(color='#2ca02c', size=20, line=dict(width=2, color='black')),
            legendgroup='athlete'
        ), row=1, col=1)

        fig.add_trace(go.Scatter(
            x=cmj_data['team_main'],
            y=cmj_data['main_labels'],
            mode='markers',
            name='Team Average',
            marker=dict(color='#ff7f0e', size=20, line=dict(width=2, color='black')),
            legendgroup='team'
        ), row=1, col=1)

        # RSI (row 2)
        if cmj_data['rsi_athlete'] is not None:
            fig.add_trace(go.Scatter(
                x=[cmj_data['rsi_athlete']],
                y=['RSI-modified (Imp-Mom)'],
                mode='markers',
                name=cmj_data['name'],
                showlegend=False,
                marker=dict(color='#2ca02c', size=25, line=dict(width=2, color='black')),
                legendgroup='athlete'
            ), row=2, col=1)
            fig.add_trace(go.Scatter(
                x=[cmj_data['rsi_team']],
                y=['RSI-modified (Imp-Mom)'],
                mode='markers',
                name='Team Average',
                showlegend=False,
                marker=dict(color='#ff7f0e', size=25, line=dict(width=2, color='black')),
                legendgroup='team'
            ), row=2, col=1)

        # Layout
        fig.update_layout(
            height=450,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            legend=dict(x=0.01, y=0.99, bgcolor='rgba(255,255,255,0.9)'),
            margin=dict(l=180, r=50, t=80, b=50)
        )

        # Safely set x-axis range for Row 1
        all_main_vals = cmj_data['athlete_main'] + cmj_data['team_main']
        if all_main_vals:
            x_max = max(v for v in all_main_vals if v is not None) * 1.15
            fig.update_xaxes(range=[0, x_max], row=1, col=1)
        else:
            fig.update_xaxes(range=[0, 100], row=1, col=1)

        # RSI axis
        if cmj_data['rsi_athlete'] is not None:
            fig.update_xaxes(range=[0, 1], row=2, col=1)
        fig.update_yaxes(title="Metric", row=1, col=1)

        # Teal title bar
        fig.add_annotation(
            x=0.5, y=1.02, xref='paper', yref='paper',
            text='CMJ MEAN – ATHLETE vs TEAM',
            font=dict(size=14, color='white', family="Arial Black"),
            bgcolor='#008080', borderpad=6, xanchor='center'
        )
        fig.add_annotation(
            x=0.5, y=0.98, xref='paper', yref='paper',
            text=cmj_data['name'],
            font=dict(size=12, color='gray'),
            xanchor='center'
        )

        st.plotly_chart(fig, use_container_width=True, key="cmj_comparison")
    else:
        # === PLACEHOLDER FOR MISSING DATA ===
        fig = go.Figure()
        fig.update_layout(
            title="CMJ Mean – Athlete vs Team",
            title_x=0.5,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            height=450,
            margin=dict(l=180, r=50, t=80, b=50)
        )
        fig.add_annotation(
            text="CMJ comparison data not available",
            x=0.5, y=0.5,
            xref="paper", yref="paper",
            showarrow=False,
            font=dict(size=12, color="gray"),
            align="center"
        )
        st.plotly_chart(fig, use_container_width=True, key="cmj_comparison_placeholder")

    st.markdown('</div>', unsafe_allow_html=True)


# with col2:  
#     st.markdown("#### Isokinetic Peak Torque (60°/s)")
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)

#     # Use isokinetic function with iso_df
#     torque_data = get_isokinetic_torque_data(iso_df, selected_athlete)

#     if torque_data:
#         dom_flx = torque_data['dominant_flexor']
#         dom_ext = torque_data['dominant_extensor']
#         non_flx = torque_data['non_dominant_flexor']
#         non_ext = torque_data['non_dominant_extensor']
#         norm_flx = torque_data['norm_flexor']
#         norm_ext = torque_data['norm_extensor']
#         name = torque_data['name']
#         gender = torque_data['gender']

#         has_data = all(pd.notna(v) for v in [dom_flx, dom_ext, non_flx, non_ext])

#         if has_data:
#             fig = go.Figure()

#             # Dominant (blue)
#             fig.add_trace(go.Scatter(
#                 x=[dom_flx], y=[dom_ext],
#                 mode='markers+text',
#                 name='Dominant Leg',
#                 marker=dict(color='#1f77b4', size=20, line=dict(color='black', width=1.5)),
#                 text=[f"Dom:({dom_flx:.0f}, {dom_ext:.0f})"],
#                 textposition='top right',
#                 textfont=dict(size=9, color='#1f77b4'),
#                 showlegend=True
#             ))

#             # Non-Dominant (red)
#             fig.add_trace(go.Scatter(
#                 x=[non_flx], y=[non_ext],
#                 mode='markers+text',
#                 name='Non-Dominant Leg',
#                 marker=dict(color='#d62728', size=20, line=dict(color='black', width=1.5)),
#                 text=[f"Non-Dom:({non_flx:.0f}, {non_ext:.0f})"],
#                 textposition='top right',
#                 textfont=dict(size=9, color='#d62728'),
#                 showlegend=True
#             ))

#             # Norm lines
#             fig.add_vline(x=norm_flx, line=dict(color='green', dash='dot', width=2),
#                           annotation_text=f"Norm Flexor ({norm_flx} Nm)")
#             fig.add_hline(y=norm_ext, line=dict(color='green', dash='dot', width=2),
#                           annotation_text=f"Norm Extensor ({norm_ext} Nm)")

#             # Layout
#             fig.update_layout(
#                 title=f"Peak Torque at 60°/s<br><sup>{name} ({gender})</sup>",
#                 xaxis=dict(title="Flexor Peak Torque (Nm)", range=[40, 180], gridcolor='lightgray'),
#                 yaxis=dict(title="Extensor Peak Torque (Nm)", range=[70, 280], gridcolor='lightgray'),
#                 plot_bgcolor='rgba(0,0,0,0)',
#                 paper_bgcolor='rgba(0,0,0,0)',
#                 height=500,
#                 legend=dict(x=0.02, y=0.98, bgcolor='rgba(255,255,255,0.8)'),
#                 margin=dict(t=80, b=50, l=60, r=40)
#             )

#             st.plotly_chart(fig, use_container_width=True, key="isokinetic_torque")
#         else:
#             st.caption("Incomplete torque data (missing one or more values).")
#     else:
#         st.caption(f"No isokinetic data found for **{selected_athlete}**.")

#     st.markdown('</div>', unsafe_allow_html=True)
# Chart 4: YBT Directions (Left)
with col2:
    st.markdown("#### Isokinetic Peak Torque (60°/s)")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)

    torque_data = get_isokinetic_torque_data(iso_df, selected_athlete)

    if torque_data:
        dom_flx = torque_data['dominant_flexor']
        dom_ext = torque_data['dominant_extensor']
        non_flx = torque_data['non_dominant_flexor']
        non_ext = torque_data['non_dominant_extensor']
        norm_flx = torque_data['norm_flexor']
        norm_ext = torque_data['norm_extensor']
        name = torque_data['name']
        gender = torque_data['gender']

        has_data = all(pd.notna(v) for v in [dom_flx, dom_ext, non_flx, non_ext])

        if has_data:
            fig = go.Figure()

            # Dominant (blue)
            fig.add_trace(go.Scatter(
                x=[dom_flx], y=[dom_ext],
                mode='markers+text',
                name='Dominant Leg',
                marker=dict(color='#1f77b4', size=20, line=dict(color='black', width=1.5)),
                text=[f"Dom:({dom_flx:.0f}, {dom_ext:.0f})"],
                textposition='top right',
                textfont=dict(size=9, color='#1f77b4'),
                showlegend=True
            ))

            # Non-Dominant (red)
            fig.add_trace(go.Scatter(
                x=[non_flx], y=[non_ext],
                mode='markers+text',
                name='Non-Dominant Leg',
                marker=dict(color='#d62728', size=20, line=dict(color='black', width=1.5)),
                text=[f"Non-Dom:({non_flx:.0f}, {non_ext:.0f})"],
                textposition='top right',
                textfont=dict(size=9, color='#d62728'),
                showlegend=True
            ))

            # Norm lines
            fig.add_vline(x=norm_flx, line=dict(color='green', dash='dot', width=2),
                          annotation_text=f"Norm Flexor ({norm_flx} Nm)",
                          annotation_position="top left")
            fig.add_hline(y=norm_ext, line=dict(color='green', dash='dot', width=2),
                          annotation_text=f"Norm Extensor ({norm_ext} Nm)",
                          annotation_position="bottom right")

            # Layout
            fig.update_layout(
                title=f"Peak Torque at 60°/s<br><sup>{name} ({gender})</sup>",
                xaxis=dict(title="Flexor Peak Torque (Nm)", range=[40, 180], gridcolor='lightgray'),
                yaxis=dict(title="Extensor Peak Torque (Nm)", range=[70, 280], gridcolor='lightgray'),
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                height=450,
                legend=dict(x=0.02, y=0.98, bgcolor='rgba(255,255,255,0.8)'),
                margin=dict(t=80, b=50, l=60, r=40)
            )

            st.plotly_chart(fig, use_container_width=True, key="isokinetic_torque")
        else:
            # === PLACEHOLDER: Incomplete data ===
            fig = go.Figure()
            fig.update_layout(
                title="Isokinetic Peak Torque (60°/s)",
                title_x=0.5,
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                xaxis=dict(visible=False),
                yaxis=dict(visible=False),
                height=500,
                margin=dict(t=80, b=50, l=60, r=40)
            )
            fig.add_annotation(
                text="Incomplete torque data (missing one or more values)",
                x=0.5, y=0.5,
                xref="paper", yref="paper",
                showarrow=False,
                font=dict(size=12, color="gray"),
                align="center"
            )
            st.plotly_chart(fig, use_container_width=True, key="isokinetic_placeholder_incomplete")
    else:
        # === PLACEHOLDER: No athlete match ===
        fig = go.Figure()
        fig.update_layout(
            title="Isokinetic Peak Torque (60°/s)",
            title_x=0.5,
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            height=450,
            margin=dict(t=80, b=50, l=60, r=40)
        )
        fig.add_annotation(
            text=f"No isokinetic data found for **{selected_athlete}**",
            x=0.5, y=0.5,
            xref="paper", yref="paper",
            showarrow=False,
            font=dict(size=12, color="gray"),
            align="center"
        )
        st.plotly_chart(fig, use_container_width=True, key="isokinetic_placeholder_missing")

    st.markdown('</div>', unsafe_allow_html=True)


with col3:
    st.markdown("#### ")
    st.markdown('<div class="plot-container">', unsafe_allow_html=True)
    # Placeholder figure for missing data
    fig = go.Figure()
    fig.update_layout(
        title="Data missing",
        title_x=0.5,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        height=450,
        # width=400,
        margin=dict(t=40, b=40, l=50, r=30)
    )
    fig.add_annotation(
        text="Data missing",
        x=0.5, y=0.5,
        xref="paper", yref="paper",
        showarrow=False,
        font=dict(size=12, color="gray"),
        align="center"
    )

    st.plotly_chart(fig, use_container_width=False, key="placeholder_missing_data")
    st.markdown('</div>', unsafe_allow_html=True)



# # ======================
# # SECTION 5: YBT COMPARISON (3:1 ratio)
# # ======================
# st.markdown("### YBT Summary")
# col1, col2 = st.columns([3, 1])

# # Chart 1: YBT Directional Comparison (All 6 directions)
# with col1:
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)
#     directions = ['Anterior', 'Lateral', 'Medial']
#     right_vals = [
#         safe_get(df['YBT RA Relative (normalized) (%)']),
#         safe_get(df['YBT RL Relative (normalized) (%)']),
#         safe_get(df['YBT RM Relative (normalized) (%)'])
#     ]
#     left_vals = [
#         safe_get(df['YBT LA Relative (normalized) (%)']),
#         safe_get(df['YBT LL Relative (normalized) (%)']),
#         safe_get(df['YBT LM Relative (normalized) (%)'])
#     ]
#     if all(v is not None for v in right_vals + left_vals):
#         fig = go.Figure()
#         fig.add_trace(go.Bar(name='Right', x=directions, y=right_vals, marker_color='royalblue'))
#         fig.add_trace(go.Bar(name='Left', x=directions, y=left_vals, marker_color='tomato'))
#         fig.update_layout(
#             title="YBT: Directional Comparison",
#             yaxis_title="Normalized (%)",
#             barmode='group',
#             plot_bgcolor='rgba(0,0,0,0)',
#             paper_bgcolor='rgba(0,0,0,0)'
#         )
#         st.plotly_chart(fig, use_container_width=True)
#     else:
#         st.caption("Directional YBT data incomplete")
#     st.markdown('</div>', unsafe_allow_html=True)

# # Chart 2: Composite YBT Summary
# with col2:
#     st.markdown('<div class="plot-container">', unsafe_allow_html=True)
#     r_comp = safe_get(df['R_Composite (%)'])
#     l_comp = safe_get(df['L_Composite (%)'])
#     if r_comp is not None and l_comp is not None:
#         fig = go.Figure()
#         fig.add_trace(go.Bar(
#             x=['Right', 'Left'],
#             y=[r_comp, l_comp],
#             marker_color=['royalblue', 'tomato']
#         ))
#         fig.update_layout(
#             title="Composite YBT (%)",
#             plot_bgcolor='rgba(0,0,0,0)',
#             paper_bgcolor='rgba(0,0,0,0)'
#         )
#         st.plotly_chart(fig, use_container_width=True)
#     else:
#         st.caption("Composite YBT missing")
#     st.markdown('</div>', unsafe_allow_html=True)

# ======================
# FOOTER
# ======================
st.markdown(
    """
    <div class="footer">
        <p>Fencing Preseason Dashboard • November 2025</p>
    </div>
    """,
    unsafe_allow_html=True
)