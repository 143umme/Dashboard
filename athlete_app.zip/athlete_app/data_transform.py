# data_transform.py
import pandas as pd
import numpy as np

def load_data():
    """Load from root directory with encoding fallback."""
    encodings = ['utf-8', 'latin1', 'cp1252']
    for enc in encodings:
        try:
            df = pd.read_csv("data/Fencing preseason Final Data.csv", encoding=enc)
            return df
        except UnicodeDecodeError:
            continue
    raise ValueError("Could not decode CSV with common encodings.")

def clean_data(df):
    # Fix column names: replace \xa0 (non-breaking space) with regular space
    df.columns = df.columns.str.replace('\xa0', ' ', regex=False).str.strip()
    
    # Convert all non-ID columns to numeric (ID = Athletes, Group, Dominant side)
    id_cols = ['Athletes', 'Group', 'Dominant side']
    for col in df.columns:
        if col not in id_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')         
    return df


######### -  ----------------  Extraction -----------------  #########
## Section 3 
def get_jump_height_data(df, athlete_row):
    """
    Extracts jump height data for a single athlete (by row index) for longitudinal plotting.
    
    Returns:
        dict with keys:
            - 'name': athlete name
            - 'years': list of years (e.g., [2025, 2026, 2027])
            - 'values': list of jump heights (float or None for missing)
    """
    if athlete_row >= len(df):
        return None

    athlete = df.iloc[athlete_row]
    name = athlete.get('Athletes', 'Unknown Athlete')
    
    # Define the jump height column
    mean_col = 'CMJ MEAN Jump Height (Imp-Mom) (cm)'
    value_2025 = pd.to_numeric(athlete.get(mean_col), errors='coerce')

    # Assume only 2025 has data; future years are NaN
    years = [2025, 2026, 2027]
    values = [value_2025, None, None]

    return {
        'name': name,
        'years': years,
        'values': values
    }




def get_cmj_peak_power_data(df, athlete_row=0):
    """
    Extracts CMJ Mean Peak Power normalized by body mass (W/kg) for a single athlete.
    
    Parameters:
        df (pd.DataFrame): Full athlete dataset.
        athlete_row (int): Row index of the athlete (default: 0 for first athlete).
    
    Returns:
        dict or None: Dictionary with keys:
            - 'name': Athlete name (str)
            - 'value_2025': Peak power value for 2025 (float or None if missing)
    """
    if athlete_row >= len(df):
        return None

    athlete = df.iloc[athlete_row]
    name = athlete.get('Athletes', 'Unknown Athlete')
    col = 'CMJ MEAN Peak Power / BM (W/kg)'
    value_2025 = pd.to_numeric(athlete.get(col), errors='coerce')

    return {
        'name': name,
        'value_2025': value_2025
    }




def get_ktw_longitudinal_data(df, athlete_row=0):
    """
    Extracts KTW (Knee-to-Wall) Dominant and Non-Dominant values for a single athlete.
    
    Parameters:
        df (pd.DataFrame): Full athlete dataset.
        athlete_row (int): Index of the athlete (default: 0).
    
    Returns:
        dict or None: Contains:
            - 'name': Athlete name
            - 'dominant_2025': float or None
            - 'non_dominant_2025': float or None
    """
    if athlete_row >= len(df):
        return None

    athlete = df.iloc[athlete_row]
    name = athlete.get('Athletes', 'Unknown Athlete')
    
    dom_col = 'KTW Dominant (cm)'
    non_dom_col = 'KTW Non Dominant (cm)'
    
    dominant_2025 = pd.to_numeric(athlete.get(dom_col), errors='coerce')
    non_dominant_2025 = pd.to_numeric(athlete.get(non_dom_col), errors='coerce')

    return {
        'name': name,
        'dominant_2025': dominant_2025,
        'non_dominant_2025': non_dominant_2025
    }


## Section 4

# def get_slj_mean_asymmetry_data(df, athlete_row=0):
#     """
#     Extracts SLJ Mean metrics (Non-Dom, Dom, Asymmetry %) for a single athlete.
    
#     Returns:
#         dict with:
#             - 'name': athlete name
#             - 'metrics': list of metric short names (y-axis labels)
#             - 'non_dominant': list of float values
#             - 'dominant': list of float values
#             - 'asymmetry': list of asymmetry % (float)
#     """
#     if athlete_row >= len(df):
#         return None

#     athlete = df.iloc[athlete_row]
#     name = athlete.get('Athletes', 'Unknown Athlete')

#     # Define metric groups (same as your script)
#     groups = [
#         ('SLJ MEAN Non Dominant Jump Height (Imp-Mom)  (cm)', 'SLJ MEAN Dominant Jump Height (Imp-Mom)  (cm)',
#          'SLJ MEAN Non Dominant/Dominant Jump Height (Imp-Mom)  ASYM %', 'Jump Height (cm)'),
#         ('SLJ MEAN Non Dominant Peak Power / BM  (W/kg)', 'SLJ MEAN Dominant Peak Power / BM  (W/kg)',
#          'SLJ MEAN Non Dominant/Dominant Peak Power / BM  ASYM %', 'Peak Power / BM (W/kg)'),
#         ('SLJ MEAN Non Dominant RSI-modified (Imp-Mom) (m/s)', 'SLJ MEAN Dominant RSI-modified (Imp-Mom) (m/s)',
#          'SLJ MEAN Non Dominant/Dominant RSI-modified (Imp-Mom) ASYM %', 'RSI-modified (m/s)'),
#         ('SLJ MEAN Non Dominant EDRFD/BM   (N/s/kg)', 'SLJ MEAN Dominant EDRFD/BM  (N/s/kg)',
#          'SLJ MEAN Non Dominant/Dominant EDRFD/BM  ASYM %', 'EDRFD / BM (N/s/kg)'),
#         ('SLJ MEAN Non Dominant Concentric impulse 100ms   (N/s)', 'SLJ MEAN Dominant Concentric impulse 100ms  (N/s)',
#          'SLJ MEAN Non Dominant/Dominant Concentric impulse 100ms  ASYM %', 'Concentric impulse 100ms (N/s)'),
#         ('SLJ MEAN Non Dominant Landing impulse (N/s)', 'SLJ MEAN Dominant Landing impulse (N/s)',
#          'SLJ MEAN Non Dominant/Dominant Landing impulse ASYM %', 'Landing impulse (N/s)'),
#     ]

#     metrics = []
#     non_dom_vals = []
#     dom_vals = []
#     asym_vals = []

#     def parse_asym(val):
#         if pd.isna(val):
#             return None
#         s = str(val).strip().replace(' R', '').replace(' L', '').replace('R', '').replace('L', '').replace('%', '').strip()
#         try:
#             return float(s)
#         except:
#             return None

#     for L_col, R_col, A_col, short_name in groups:
#         L = pd.to_numeric(athlete.get(L_col), errors='coerce')
#         R = pd.to_numeric(athlete.get(R_col), errors='coerce')
#         A_raw = athlete.get(A_col)
#         A = parse_asym(A_raw)

#         # Only include if all three values are valid
#         if pd.notna(L) and pd.notna(R) and A is not None and not pd.isna(A):
#             metrics.append(short_name)
#             non_dom_vals.append(L)
#             dom_vals.append(R)
#             asym_vals.append(A)

#     if not metrics:
#         return None

#     return {
#         'name': name,
#         'metrics': metrics,
#         'non_dominant': non_dom_vals,
#         'dominant': dom_vals,
#         'asymmetry': asym_vals
#     }
def parse_asymmetry_value(val):
    """Clean and parse asymmetry values (e.g., '5.2 R' → 5.2)."""
    if pd.isna(val):
        return None
    s = str(val).strip()
    # Remove direction indicators and %
    s = s.replace(' R', '').replace(' L', '').replace('R', '').replace('L', '').replace('%', '').strip()
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def get_slj_mean_asymmetry_data(df, athlete_name):
    """
    Extract SLJ Mean asymmetry data for a single athlete by name.
    
    Returns:
        dict or None with keys:
            - 'name': athlete name
            - 'metrics': list of short metric names
            - 'non_dominant': list of float values
            - 'dominant': list of float values
            - 'asymmetry': list of asymmetry % (float)
    """
    athlete_row = df[df['Athletes'] == athlete_name]
    if athlete_row.empty:
        return None

    athlete = athlete_row.iloc[0]
    name = athlete.get('Athletes', 'Unknown Athlete')

    # Define metric groups (aligned with your CSV column names)
    groups = [
        ('SLJ MEAN Non Dominant Jump Height (Imp-Mom)  (cm)', 'SLJ MEAN Dominant Jump Height (Imp-Mom)  (cm)',
         'SLJ MEAN Non Dominant/Dominant Jump Height (Imp-Mom)  ASYM %', 'Jump Height (cm)'),
        ('SLJ MEAN Non Dominant Peak Power / BM  (W/kg)', 'SLJ MEAN Dominant Peak Power / BM  (W/kg)',
         'SLJ MEAN Non Dominant/Dominant Peak Power / BM  ASYM %', 'Peak Power / BM (W/kg)'),
        ('SLJ MEAN Non Dominant RSI-modified (Imp-Mom) (m/s)', 'SLJ MEAN Dominant RSI-modified (Imp-Mom) (m/s)',
         'SLJ MEAN Non Dominant/Dominant RSI-modified (Imp-Mom) ASYM %', 'RSI-modified (m/s)'),
        ('SLJ MEAN Non Dominant EDRFD/BM   (N/s/kg)', 'SLJ MEAN Dominant EDRFD/BM  (N/s/kg)',
         'SLJ MEAN Non Dominant/Dominant EDRFD/BM  ASYM %', 'EDRFD / BM (N/s/kg)'),
        ('SLJ MEAN Non Dominant Concentric impulse 100ms   (N/s)', 'SLJ MEAN Dominant Concentric impulse 100ms  (N/s)',
         'SLJ MEAN Non Dominant/Dominant Concentric impulse 100ms  ASYM %', 'Concentric impulse 100ms (N/s)'),
        ('SLJ MEAN Non Dominant Landing impulse (N/s)', 'SLJ MEAN Dominant Landing impulse (N/s)',
         'SLJ MEAN Non Dominant/Dominant Landing impulse ASYM %', 'Landing impulse (N/s)'),
    ]

    metrics = []
    non_dom_vals = []
    dom_vals = []
    asym_vals = []

    for L_col, R_col, A_col, short_name in groups:
        # Check if columns exist
        if L_col not in athlete.index or R_col not in athlete.index or A_col not in athlete.index:
            continue

        L = pd.to_numeric(athlete[L_col], errors='coerce')
        R = pd.to_numeric(athlete[R_col], errors='coerce')
        A_raw = athlete[A_col]
        A = parse_asymmetry_value(A_raw)

        # Only include if all three values are valid
        if pd.notna(L) and pd.notna(R) and A is not None and not pd.isna(A):
            metrics.append(short_name)
            non_dom_vals.append(L)
            dom_vals.append(R)
            asym_vals.append(A)

    if not metrics:
        return None

    return {
        'name': name,
        'metrics': metrics,
        'non_dominant': non_dom_vals,
        'dominant': dom_vals,
        'asymmetry': asym_vals
    }

 
def get_ybt_directional_data(df, athlete_name):
    """
    Extract Y-Balance Test (YBT) directional reach data for a single athlete by name.
    
    Returns:
        dict or None with keys:
            - 'name': athlete name
            - 'metrics': list of directions (e.g., ['Anterior', 'Medial', ...])
            - 'left': list of left leg % values
            - 'right': list of right leg % values
    """
    athlete_row = df[df['Athletes'] == athlete_name]
    if athlete_row.empty:
        return None
    
    a = athlete_row.iloc[0]
    
    # Map metrics to columns
    col_map = {
        'Anterior': ('YBT LA Relative (normalized) (%)', 'YBT RA Relative (normalized) (%)'),
        'Medial': ('YBT LM Relative (normalized) (%)', 'YBT RM Relative (normalized) (%)'),
        'Lateral': ('YBT LL Relative (normalized) (%)', 'YBT RL Relative (normalized) (%)'),
        'Composite': ('L_Composite (%)', 'R_Composite (%)')
    }
    
    metrics = []
    left_vals = []
    right_vals = []
    
    for metric, (left_col, right_col) in col_map.items():
        L = pd.to_numeric(a.get(left_col), errors='coerce')
        R = pd.to_numeric(a.get(right_col), errors='coerce')
        
        # Only include if at least one side is present (Plotly handles missing)
        metrics.append(metric)
        left_vals.append(L)
        right_vals.append(R)
    
    return {
        'name': athlete_name,
        'metrics': metrics,
        'left': left_vals,
        'right': right_vals
    }


def get_slh_rsi_data(df, athlete_name):
    """
    Extract SLH Mean RSI (Non-Dom, Dom, Asymmetry %) for a single athlete by name.
    
    Returns:
        dict or None with keys:
            - 'name': athlete name
            - 'non_dominant': float or None
            - 'dominant': float or None
            - 'asymmetry': float or None
    """
    athlete_row = df[df['Athletes'] == athlete_name]
    if athlete_row.empty:
        return None
    
    a = athlete_row.iloc[0]
    
    L_COL = 'SLH MEAN Non Dominant RSI (m/s)'
    R_COL = 'SLH MEAN Dominant RSI (m/s)'
    ASYM_COL = 'SLH MEAN Non Dominant/Dominant RSI ASYM %'
    
    L = pd.to_numeric(a.get(L_COL), errors='coerce')
    R = pd.to_numeric(a.get(R_COL), errors='coerce')
    
    # Parse asymmetry
    asym_raw = a.get(ASYM_COL)
    asym = None
    if pd.notna(asym_raw):
        s = str(asym_raw).strip()
        if s.endswith(('R', 'L')):
            s = s[:-1].strip()
        s = s.replace('%', '').strip()
        try:
            asym = float(s)
        except:
            asym = None
    
    # Only return if at least RSI values exist
    if pd.isna(L) and pd.isna(R):
        return None
    
    return {
        'name': athlete_name,
        'non_dominant': L,
        'dominant': R,
        'asymmetry': asym
    }


##------------------- Section 5 -----------------## 

def get_cmj_team_comparison_data(df, athlete_name):
    """
    Extract CMJ metrics for one athlete and team averages for comparison.
    
    Returns:
        dict or None with keys:
            - 'name': athlete name
            - 'main_labels': list of metric names
            - 'athlete_main': list of athlete values
            - 'team_main': list of team average values
            - 'rsi_athlete': float or None
            - 'rsi_team': float or None
    """
    if 'Athletes' not in df.columns:
        return None

    # Get athlete row
    athlete_row = df[df['Athletes'] == athlete_name]
    if athlete_row.empty:
        return None
    athlete = athlete_row.iloc[0]

    # Define main metrics
    main_metrics = [
        ("Jump Height (Imp-Mom)(cm)", 'CMJ MEAN Jump Height (Imp-Mom) (cm)'),
        ("Peak Power / BM (W/Kg)",   'CMJ MEAN Peak Power / BM (W/kg)'),
        ("EDRFD/BM",                 'CMJ MEAN EDRFD/BM'),
        ("Concentric impulse 100ms", 'CMJ MEAN Concentric impulse 100ms'),
        ("Landing impulse",          'CMJ MEAN Landing impulse')
    ]
    
    # Helper: safe team mean
    def safe_mean(col):
        if col not in df.columns:
            return np.nan
        series = pd.to_numeric(df[col], errors='coerce')
        return series.replace([np.inf, -np.inf], np.nan).mean()

    # Extract main metrics
    main_labels, athlete_main, team_main = [], [], []
    for label, col in main_metrics:
        if col not in df.columns:
            continue
        val = pd.to_numeric(athlete.get(col), errors='coerce')
        avg = safe_mean(col)
        if pd.notna(val) and pd.notna(avg):
            main_labels.append(label)
            athlete_main.append(float(val))
            team_main.append(float(avg))

    # Extract RSI
    rsi_col = 'CMJ MEAN RSI-modified (Imp-Mom)'
    rsi_athlete = rsi_team = None
    if rsi_col in df.columns:
        rsi_val = pd.to_numeric(athlete.get(rsi_col), errors='coerce')
        rsi_avg = safe_mean(rsi_col)
        if pd.notna(rsi_val) and pd.notna(rsi_avg):
            rsi_athlete = float(rsi_val)
            rsi_team = float(rsi_avg)

    return {
        'name': athlete_name,
        'main_labels': main_labels,
        'athlete_main': athlete_main,
        'team_main': team_main,
        'rsi_athlete': rsi_athlete,
        'rsi_team': rsi_team
    }





def get_isokinetic_torque_data(iso_df, athlete_name):
    """
    Extract isokinetic torque data for a given athlete from the isokinetic dataset.
    
    Parameters:
        iso_df (pd.DataFrame): DataFrame loaded from 'Fencing_Preseason_Isokinetic data.csv'
        athlete_name (str): Name of the athlete
    
    Returns:
        dict or None with torque and gender info.
    """
    if 'Athlete' not in iso_df.columns:
        return None

    athlete_row = iso_df[iso_df['Athlete'] == athlete_name]
    if athlete_row.empty:
        return None

    a = athlete_row.iloc[0]
    name = a.get('Athlete', 'Unknown').strip()
    gender_raw = str(a.get('Gender', '')).strip().lower()

    # Gender & norms (support English)
    if 'male' in gender_raw:
        gender = 'Male'
        norm_ext = 240
        norm_flx = 140
    else:
        gender = 'Female'
        norm_ext = 155
        norm_flx = 95

    # Extract torque values
    dom_ext = pd.to_numeric(a.get('Dominant_Extensor(Nm)'), errors='coerce')
    non_ext = pd.to_numeric(a.get('Non Dominant_Extensor(Nm)'), errors='coerce')
    dom_flx = pd.to_numeric(a.get('Dominant_Flexor(Nm)'), errors='coerce')
    non_flx = pd.to_numeric(a.get('Non Dominant_Flexor(Nm)'), errors='coerce')

    return {
        'name': name,
        'gender': gender,
        'dominant_flexor': dom_flx,
        'dominant_extensor': dom_ext,
        'non_dominant_flexor': non_flx,
        'non_dominant_extensor': non_ext,
        'norm_flexor': norm_flx,
        'norm_extensor': norm_ext
    }




# def get_ybt_directional_data(row):
#     """
#     Extract YBT directional values for a single athlete.
#     Returns dict with metrics, left, right values.
#     """
#     metrics = ['Anterior', 'Medial', 'Lateral', 'Composite']
#     left_cols = [
#         'YBT LA Relative (normalized) (%)',
#         'YBT LM Relative (normalized) (%)',
#         'YBT LL Relative (normalized) (%)',
#         'L_Composite (%)'
#     ]
#     right_cols = [
#         'YBT RA Relative (normalized) (%)',
#         'YBT RM Relative (normalized) (%)',
#         'YBT RL Relative (normalized) (%)',
#         'R_Composite (%)'
#     ]
#     left_vals = [row.get(col) for col in left_cols]
#     right_vals = [row.get(col) for col in right_cols]
#     return {
#         'metrics': metrics,
#         'left': left_vals,
#         'right': right_vals
#     }


